const { select, execute } = require('@evershop/postgres-query-builder');
const { buildUrl } = require('@evershop/evershop/src/lib/router/buildUrl');
const { camelCase } = require('@evershop/evershop/src/lib/util/camelCase');
const {
  getProductsByCategoryBaseQuery
} = require('../../../services/getProductsByCategoryBaseQuery');
const {
  getProductsByTagBaseQuery
} = require('../../../services/getProductsByTagBaseQuery');
const {
  getFilterableAttributes
} = require('../../../services/getFilterableAttributes');
const { ProductCollection } = require('../../../services/ProductCollection');
const {
  getTagBaseQuery
} = require('../../../services/getTagBaseQuery');
const { TagCollection } = require('../../../services/TagCollection');

module.exports = {
  Query: {
    tag: async (_, { id }, { pool }) => {
      const query = select().from('tags');
      query.where('id', '=', id);
      const result = await query.load(pool);
      return result ? camelCase(result) : null;
    },
    tags: async (_, { filters = [] }, { user }) => {
      const query = getTagBaseQuery();
      const root = new TagCollection(query);
      await root.init(filters, !!user);
      return root;
    }
  },
  Category: {
    products: async (tag, { filters = [] }, { user }) => {
      const query = await getProductsByTagBaseQuery(
        tag.product_id,
        !user
      );
      const root = new ProductCollection(query);
      await root.init(filters, !!user);
      return root;
    },
    availableAttributes: async (category) => {
      const results = await getFilterableAttributes(category.categoryId);
      return results;
    },
    priceRange: async (category, _, { pool }) => {
      const query = await getProductsByCategoryBaseQuery(
        category.categoryId,
        true
      );
      query
        .select('MIN(product.price)', 'min')
        .select('MAX(product.price)', 'max');
      const result = await query.load(pool);
      return {
        min: result.min || 0,
        max: result.max || 0
      };
    },
    url: async (tag, _, { pool }) => {
      // Get the url rewrite for this category
      const urlRewrite = await select()
        .from('url_rewrite')
        .where('entity_uuid', '=', tag.id)
        .and('entity_type', '=', 'category')
        .load(pool);
      if (!urlRewrite) {
        return buildUrl('TagView', { uuid: tag.id });
      } else {
        return urlRewrite.request_path;
      }
    },
    children: async (tag, _, { pool }) => {
      const query = select().from('tags');      
      // query.where('tags.id', '=', tag.id);
      const results = await query.execute(pool);
      return results.map((row) => camelCase(row));
    }    
  },
  Product: {
    tag: async (product, _, { pool }) => {
      if (!product.id) {
        return null;
      } else {
        const tagyQuery = getTagBaseQuery();
        tagyQuery.where('product_id', '=', product.id);
        const tag = await tagyQuery.load(pool);
        return camelCase(tag);
      }
    }
  }
};
